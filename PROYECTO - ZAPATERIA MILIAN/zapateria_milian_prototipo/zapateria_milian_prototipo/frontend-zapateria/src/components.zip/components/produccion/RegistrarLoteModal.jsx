import { useState } from 'react'


function RegistrarLoteModal({
  orden,
  guardar,
  cerrarModal
}) {

  const [fecha, setFecha] =
    useState('')

  const [observacion, setObservacion] =
    useState('')


  const [tallas, setTallas] =
    useState(
      orden.tallas
        .map(talla => ({
          talla:
            talla.talla,

          pendiente:
            talla.solicitada -
            talla.producida,

          cantidad: ''
        }))
        .filter(
          talla =>
            talla.pendiente > 0
        )
    )


  function cambiarCantidad(
    talla,
    valor
  ) {

    setTallas(
      tallas.map(item => {

        if (
          item.talla !== talla
        ) {
          return item
        }

        return {
          ...item,
          cantidad: valor
        }
      })
    )
  }


  const totalLote =
    tallas.reduce(
      (total, talla) =>
        total +
        (Number(
          talla.cantidad
        ) || 0),
      0
    )


  function enviar(evento) {

    evento.preventDefault()


    if (!fecha) {

      window.alert(
        'Selecciona la fecha del lote.'
      )

      return
    }


    if (totalLote <= 0) {

      window.alert(
        'Debes producir al menos un par.'
      )

      return
    }


    guardar({
      fecha,

      tallas:
        tallas.map(
          talla => ({
            talla:
              talla.talla,

            cantidad:
              Number(
                talla.cantidad
              ) || 0
          })
        ),

      observacion
    })
  }


  return (
    <div className="modal show">

      <div
        className="modal-backdrop"
        onClick={cerrarModal}
      />


      <div className="modal-card production-modal">

        <button
          className="modal-close"
          onClick={cerrarModal}
        >
          ×
        </button>


        <p className="eyebrow">
          Producción
        </p>

        <h3 className="modal-title">
          Registrar lote
        </h3>


        <form onSubmit={enviar}>

          <div className="form-group">

            <label>
              Fecha
            </label>

            <input
              type="date"
              value={fecha}
              onChange={
                evento =>
                  setFecha(
                    evento.target.value
                  )
              }
              required
            />

          </div>


          <div className="production-size-section">

            <p className="eyebrow">
              Producción
            </p>

            <h3>
              Pares producidos por talla
            </h3>


            <div className="table-wrap">

              <table>

                <thead>
                  <tr>
                    <th>Talla</th>
                    <th>Pendientes</th>
                    <th>Producir</th>
                  </tr>
                </thead>


                <tbody>

                  {tallas.map(
                    talla => (

                      <tr
                        key={
                          talla.talla
                        }
                      >

                        <td>
                          <strong>
                            Talla {talla.talla}
                          </strong>
                        </td>


                        <td>
                          {talla.pendiente} pares
                        </td>


                        <td>

                          <input
                            className="venta-size-input"
                            type="number"
                            min="0"
                            max={
                              talla.pendiente
                            }
                            value={
                              talla.cantidad
                            }
                            onChange={
                              evento =>
                                cambiarCantidad(
                                  talla.talla,
                                  evento.target.value
                                )
                            }
                          />

                        </td>

                      </tr>

                    )
                  )}

                </tbody>

              </table>

            </div>


            <div className="pedido-total-pares">

              <span>
                Total del lote
              </span>

              <strong>
                {totalLote} pares
              </strong>

            </div>

          </div>


          <div className="form-group">

            <label>
              Observación
            </label>

            <textarea
              value={observacion}
              onChange={
                evento =>
                  setObservacion(
                    evento.target.value
                  )
              }
              placeholder="Ej. Primer lote terminado..."
              rows="3"
            />

          </div>


          <div className="form-actions">

            <button
              type="button"
              className="btn btn-outline"
              onClick={cerrarModal}
            >
              Cancelar
            </button>


            <button
              type="submit"
              className="btn btn-gold"
            >
              Registrar lote
            </button>

          </div>

        </form>

      </div>

    </div>
  )
}


export default RegistrarLoteModal