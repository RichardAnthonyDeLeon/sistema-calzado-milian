import { useState } from 'react'


function NuevaProduccionModal({
  pedidos,
  inventario,
  fichaTecnica,
  crearProduccion,
  cerrarModal
}) {

  const [pedidoId, setPedidoId] =
    useState('')


  const pedidoSeleccionado =
    pedidos.find(
      pedido =>
        pedido.id === pedidoId
    )


  const cantidadTotal =
    pedidoSeleccionado
      ? pedidoSeleccionado.tallas.reduce(
          (total, talla) =>
            total +
            Number(talla.cantidad),
          0
        )
      : 0


  const materiales =
    fichaTecnica.map(material => {

      const inventarioMaterial =
        inventario.find(
          item =>
            item.id ===
            material.materialId
        )


      const requerido =
        material.consumo *
        cantidadTotal


      const disponible =
        inventarioMaterial
          ? inventarioMaterial.existencia
          : 0


      return {
        ...material,
        requerido,
        disponible,
        suficiente:
          disponible >= requerido
      }
    })


  const puedeIniciar =
    pedidoSeleccionado &&
    materiales.every(
      material =>
        material.suficiente
    )


  function guardar(evento) {

    evento.preventDefault()

    if (!pedidoId) {

      window.alert(
        'Selecciona un pedido.'
      )

      return
    }


    if (!puedeIniciar) {

      window.alert(
        'No hay suficientes materiales.'
      )

      return
    }


    crearProduccion(
      pedidoId
    )
  }


  return (
    <div className="modal show">

      <div
        className="modal-backdrop"
        onClick={cerrarModal}
      />


      <div className="modal-card production-modal">

        <button
          className="modal-close"
          onClick={cerrarModal}
        >
          ×
        </button>


        <p className="eyebrow">
          Producción
        </p>

        <h3 className="modal-title">
          Nueva producción
        </h3>


        <form onSubmit={guardar}>

          <div className="form-group">

            <label>
              Pedido
            </label>

            <select
              value={pedidoId}
              onChange={
                evento =>
                  setPedidoId(
                    evento.target.value
                  )
              }
              required
            >

              <option value="">
                Seleccionar pedido
              </option>


              {pedidos.map(
                pedido => (

                  <option
                    key={pedido.id}
                    value={pedido.id}
                  >
                    {pedido.id}
                    {' - '}
                    {pedido.cliente}
                    {' - '}
                    {pedido.modelo}
                  </option>

                )
              )}

            </select>


            {pedidos.length === 0 && (

              <small className="section-help">
                Actualmente no hay pedidos pendientes disponibles para iniciar producción.
              </small>

            )}

          </div>


          {pedidoSeleccionado && (

            <>

              <div className="production-summary-grid">

                <div>

                  <small>
                    Cliente
                  </small>

                  <strong>
                    {pedidoSeleccionado.cliente}
                  </strong>

                </div>


                <div>

                  <small>
                    Modelo
                  </small>

                  <strong>
                    {pedidoSeleccionado.modelo}
                  </strong>

                </div>


                <div>

                  <small>
                    Cantidad
                  </small>

                  <strong>
                    {cantidadTotal} pares
                  </strong>

                </div>

              </div>


              <div className="production-size-section">

                <p className="eyebrow">
                  Pedido
                </p>

                <h3>
                  Distribución de tallas
                </h3>


                <div className="table-wrap">

                  <table>

                    <thead>
                      <tr>
                        <th>Talla</th>
                        <th>Cantidad</th>
                      </tr>
                    </thead>


                    <tbody>

                      {pedidoSeleccionado.tallas.map(
                        talla => (

                          <tr
                            key={
                              talla.talla
                            }
                          >

                            <td>
                              Talla {talla.talla}
                            </td>

                            <td>
                              {talla.cantidad} pares
                            </td>

                          </tr>

                        )
                      )}

                    </tbody>

                  </table>

                </div>

              </div>


              <div className="production-material-section">

                <p className="eyebrow">
                  Materiales
                </p>

                <h3>
                  Material requerido
                </h3>


                <div className="table-wrap">

                  <table>

                    <thead>
                      <tr>
                        <th>Material</th>
                        <th>Necesario</th>
                        <th>Disponible</th>
                        <th>Estado</th>
                      </tr>
                    </thead>


                    <tbody>

                      {materiales.map(
                        material => (

                          <tr
                            key={
                              material.materialId
                            }
                          >

                            <td>
                              {material.nombre}
                            </td>


                            <td>
                              {material.requerido.toFixed(
                                2
                              )}
                              {' '}
                              {material.unidad}
                            </td>


                            <td>
                              {Number(
                                material.disponible
                              ).toFixed(2)}
                              {' '}
                              {material.unidad}
                            </td>


                            <td>

                              <span
                                className={
                                  material.suficiente
                                    ? 'status ready'
                                    : 'status cancelled'
                                }
                              >
                                {material.suficiente
                                  ? 'Disponible'
                                  : 'Insuficiente'}
                              </span>

                            </td>

                          </tr>

                        )
                      )}

                    </tbody>

                  </table>

                </div>

              </div>

            </>

          )}


          <div className="form-actions">

            <button
              type="button"
              className="btn btn-outline"
              onClick={cerrarModal}
            >
              Cancelar
            </button>


            <button
              type="submit"
              className="btn btn-gold"
              disabled={!puedeIniciar}
            >
              Iniciar producción
            </button>

          </div>

        </form>

      </div>

    </div>
  )
}


export default NuevaProduccionModal